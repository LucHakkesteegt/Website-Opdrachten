herhaling = True
opnieuw = True
nogmeerbolletjes = False
print ("welkom bij Papi Gelato je mag alle smaken kiezen zolang het maar vanille ijs is")
while nogmeerbolletjes is True:
    nogmeerbolletjes = False
    fout antwoord = True
    while herhaling True is:
        hoeveel = input ("Hoeveel bolletjes wilt u?")
        if de vraag tussen 1 en de 3 is:
            bakjeofhoorntje = input ("wilt u deze {aantal bolletjes ingevuld} bolletjes in een hoorntje of bakje?")
            if de vraag bakjeofhoorntje bakje is:
                print ("hier is uw bakje met {aantal bolletjes ingevuld}. ")
                herhaling = False
            elif de vraag bakjeofhoorntje hoorntje is:
                print ("hier is uw hoorntje met {aantal bolletjes ingevuld}. ")
                herhaling = False
            else:
                print ("Sorry, dat snap ik niet...")

        elif de vraag tussen de 4 en de 8 is:
            print ("Dan krijgt u van mij een bakje met {aantal bolletjes ingevuld} bolletjes")
            herhaling = False

        elif de vraag boven de 8 is:
            print ("Sorry, zulke grote bakken hebben we niet")

        else:
            print ("Sorry, dat snap ik niet...")
    foutantwoord = True
    while foutantwoord = True
    nogmeer = input ("Wilt u nog meer bestellen?").lower()
    if nogmeer is ja:
        nogmeerbolletjes = True
        foutantwoord = False
    if nogmeer is nee:
        print ("Bedankt en tot ziens")
        foutantwoord = False
    

    



