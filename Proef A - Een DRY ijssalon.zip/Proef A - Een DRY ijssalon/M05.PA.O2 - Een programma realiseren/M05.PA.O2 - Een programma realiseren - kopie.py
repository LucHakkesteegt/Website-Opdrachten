from functions import *
import os
import time
herhaling = True
aantallen = {
    'bolletjes' : 0,
    'bakjes'    : 0,
    'hoorntjes' : 0
}
prijzenTopping = {
    'prijsslagroom' : 0.50,
    'prijssprinkels' : 0.30,
    'prijscaramelsausBakje' : 0.90,
    'prijscaramelsausHoorntje' : 0.60
}
totaalSmakenBolletjes = []
totaalToppings = []
os.system('cls')
welkombij()
time.sleep(1)
while herhaling == True:
    aantalbolletjes = aantalbolletje()
    aantallen['bolletjes'] += aantalbolletjes
    time.sleep(1)
    smakenbolletjes = smaken(aantalbolletjes)
    for i in range (len(smakenbolletjes)):
        totaalSmakenBolletjes.append(smakenbolletjes[i])
    verpakkingen = verpakking(aantalbolletjes)
    if verpakkingen == "bakje":
        aantallen['bakjes'] += 1
    if verpakkingen == "hoorntje":
        aantallen['hoorntjes'] += 1
    time.sleep(1)
    toppings = topping(aantalbolletjes, prijzenTopping, verpakkingen)
    totaalToppings.append(toppings)
    samengevoegd = beiden(aantalbolletjes, verpakkingen)
    time.sleep(1)
    nogmeer         = nogmeerbestellen()
    if nogmeer == "ja":
        continue
    if nogmeer == "nee":
        print ("Bedankt en tot ziens!")
        herhaling = False
time.sleep(2)
os.system('cls')
bonnetje(aantallen, totaalSmakenBolletjes, totaalToppings)
    


     


