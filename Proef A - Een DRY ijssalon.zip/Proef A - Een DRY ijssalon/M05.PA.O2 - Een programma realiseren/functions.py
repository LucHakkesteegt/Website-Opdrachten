import time,os
def snapikniet():
    print ("Sorry, dat snap ik niet...")
    time.sleep(1)
    os.system("cls")
    return

#-----------------------------------------------------------------------------------------

def aantalbolletje():
    while True:
        try:
            aantal = int(input("Hoeveel bolletjes wilt u? "))
            if aantal >= 1 and aantal <= 8:
                return (aantal)
            elif aantal <1:
                snapikniet()
            elif aantal >8:
                print("Zulke grote bakken hebben we niet!")
        except:
            snapikniet()
        

#-----------------------------------------------------------------------------------------
def smaken(aantalbolletjes) -> list:
    herhalen = aantalbolletjes
    x = 1
    smakenbolletjes = []
    while herhalen >=1:
        smaak = input(f"Welke smaak wilt u voor bolletje nummer {x} A) Aardbei, C) Chocolade, M) Munt of V) Vanille? ").lower()
        if smaak == "a" or smaak == 'c' or smaak == 'm' or smaak == 'v':
            smakenbolletjes.append(smaak.upper())
            herhalen -= 1
            x +=1
        else:
            snapikniet()
    return (smakenbolletjes)

#-----------------------------------------------------------------------------------------

def topping(aantalbolletjes, prijzenTopping, verpakking):
    while True:
        topping = input("Wat voor topping wilt u: A) Geen, B) Slagroom, C) Sprinkels of D) Caramel Saus? ").lower()
        if topping == 'a':
            return (0)
        if topping == 'b':
            return (prijzenTopping['prijsslagroom'])
        if topping == "c":
            return (aantalbolletjes * prijzenTopping['prijssprinkels'])
        if topping == 'd' and verpakking == 'bakje':
            return (prijzenTopping['prijscaramelsausBakje'])
        if topping == 'd' and verpakking == 'hoorntje':
            return (prijzenTopping['prijscaramelsausHoorntje'])
        else:
            snapikniet()

#-----------------------------------------------------------------------------------------

def verpakking(aantalbolletjes):
    herhaling = True
    while herhaling == True:
        if aantalbolletjes >= 1 and aantalbolletjes <= 3:
            bakjeofhoorntjewil = input(f"Wilt u deze {aantalbolletjes} bolletjes in een hoorntje of bakje? ").lower()
            if bakjeofhoorntjewil == "bakje":
                return ("bakje")
            elif bakjeofhoorntjewil == "hoorntje":
                return ("hoorntje")
            else:
                snapikniet()
        if aantalbolletjes >= 4 and aantalbolletjes <= 8:
            return ("bakje")

#-----------------------------------------------------------------------------------------

def beiden(aantalbolletjes, verpakkingen):
    if verpakkingen == "bakje":
        return print (f"Hier is uw bakje met {aantalbolletjes} bolletjes")
    if verpakkingen == "hoorntje":
        return print (f"Hier is uw hoorntje met {aantalbolletjes} bolletjes")
    
#-----------------------------------------------------------------------------------------

def nogmeerbestellen():
    foutantwoord = True
    while foutantwoord == True:
        nogeenkeer = input("Wilt u nog meer bestellen? ").lower()
        if nogeenkeer == "ja":
            foutantwoord = False
            return ("ja")
        elif nogeenkeer == 'nee':
            return ("nee")
        else:
            snapikniet()
            
#-----------------------------------------------------------------------------------------

def bonnetje(aantallen, smakenbolletjes, totaalToppings):
    prijsbolletje = 1.10
    prijshoorntjes = 1.25
    prijsbakjes = 0.75
    aantalaardbij = smakenbolletjes.count("A")
    aantalchocolade = smakenbolletjes.count("C")
    aantalmunt = smakenbolletjes.count("M")
    aantalvanille = smakenbolletjes.count("V")
    aantal1 = 0
    aantal2 = 0
    aantal3 = 0
    totaalprijsTopping = 0.0
    for i in range (len(totaalToppings)):
        totaalprijsTopping += (totaalToppings[i])

    print (f"---------[Papi Gelato]---------")
    if aantallen['bolletjes'] >=1:
        if aantalaardbij >=1:
            print (f" B.aardbei    {aantalaardbij} x €1,10 = €{format(round(aantalaardbij * prijsbolletje,2), '.2f')}")
        if aantalchocolade >=1:
            print (f" B.chocolade  {aantalchocolade} x €1,10 = €{format(round(aantalchocolade * prijsbolletje,2), '.2f')}")
        if aantalmunt >=1:
            print (f" B.munt       {aantalmunt} x €1,10 = €{format(round(aantalmunt * prijsbolletje,2), '.2f')}")
        if aantalvanille >=1:
            print (f" B.vanille    {aantalvanille} x €1,10 = €{format(round(aantalvanille * prijsbolletje,2), '.2f')}")
        aantal1 = aantallen['bolletjes'] * prijsbolletje
    if aantallen['hoorntjes'] >=1:
        print (f" Hoorntjes    {aantallen['hoorntjes']} x €1.25 = €{format(round(aantallen['hoorntjes'] * prijshoorntjes,2), '.2f')}")
        aantal2 = aantallen['hoorntjes'] * prijshoorntjes
    if aantallen['bakjes'] >=1:
        print (f" Bakjes       {aantallen['bakjes']} x €0.75 = €{format(round(aantallen['bakjes'] * prijsbakjes,2), '.2f')}")
        aantal3 = aantallen['bakjes'] * prijsbakjes
    if totaalprijsTopping >0:
        print (f" Topping                = €{format(totaalprijsTopping, '.2f')}")
    print (f"                      ------- +")
    print (f" Totaal                 = €{format(round(aantal1 + aantal2 + aantal3 + totaalprijsTopping,2), '.2f')} ")

def welkombij():
    return print ("Welkom bij Papi Gelato")