from functions import *
from data import *
import os,time
herhaling = True
totaalSmakenBolletjes = []
totaalSmakenliters = []
totaalToppings = []
os.system('cls')
zakelijkofparticulier = soortklant()
if zakelijkofparticulier == "1":
    welkombij()
    time.sleep(1)
    while herhaling == True:
        aantalbolletjes = aantallenalles(zakelijkofparticulier)
        aantallen['bolletjes'] += aantalbolletjes
        time.sleep(1)
        smakenbolletjes = smaken(aantalbolletjes)
        for i in range (len(smakenbolletjes)):
            totaalSmakenBolletjes.append(smakenbolletjes[i])
        verpakkingen = verpakking(aantalbolletjes)
        aantallen[verpakkingen] += 1
        time.sleep(1)
        toppings = topping(aantalbolletjes, prijzenTopping, verpakkingen)
        totaalToppings.append(toppings)
        samengevoegd = beiden(aantalbolletjes, verpakkingen)
        time.sleep(1)
        nogmeer         = nogmeerbestellen()
        if nogmeer == "ja":
            continue
        if nogmeer == "nee":
            print ("Bedankt en tot ziens!")
            herhaling = False
    time.sleep(2)
    os.system('cls')
    bonnetjeparticulier(aantallen, totaalSmakenBolletjes, totaalToppings)
    
if zakelijkofparticulier == "2":
    aantalliters = aantallenalles(zakelijkofparticulier)
    aantallenliters['liters'] += aantalliters
    time.sleep(1)
    smaken = smakenliters(aantalliters)
    for i in range (len(smaken)):
        totaalSmakenliters.append(smaken[i])
    
    time.sleep(2)
    os.system('cls')
    bonnetjezakelijk(aantallenliters, totaalSmakenliters)

     


