PRIJS_PER_BOLLETJE = 0.95
PRIJS_PER_LITER = 9.80
PRIJS_PER_HOORNTJE = 1.25
PRIJS_PER_BAKJE = 0.75
KLANT_PARTICULIER = "1"
KLANT_ZAKELIJK = "2"

aantallen = {
    'bolletjes' : 0,
    'bakjes'    : 0,
    'hoorntjes' : 0
}
aantallenliters = {
    'liters' : 0
}
prijzenTopping = {
    'prijsslagroom' : 0.50,
    'prijssprinkels' : 0.30,
    'prijscaramelsausBakje' : 0.90,
    'prijscaramelsausHoorntje' : 0.60
}