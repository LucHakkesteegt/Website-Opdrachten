import time,os
from data import *
def snapikniet():
    print ("Sorry dat is geen optie die we aanbieden...")
    time.sleep(1)
    os.system("cls")
    return

#-----------------------------------------------------------------------------------------

def soortklant():
    while True:
        zakelijkofparticulier = input ("Bent u 1) een particuliere klant of 2) een zakelijke klant? ")
        if zakelijkofparticulier == "1" or zakelijkofparticulier == "2":
            return (zakelijkofparticulier)
        else:
            snapikniet()
            continue

#-----------------------------------------------------------------------------------------

def aantallenalles(soortklant):
    while True:
        try:
            if soortklant == KLANT_PARTICULIER:
                aantal = int(input("Hoeveel bolletjes wilt u? "))
                if aantal >= 1 and aantal <= 8:
                    return (aantal)
                elif aantal <1:
                    snapikniet()
                elif aantal >8:
                    print("Zulke grote bakken hebben we niet!")
            elif soortklant == KLANT_ZAKELIJK:
                while True:
                    aantal = int(input("Hoeveel liters wilt u? "))
                    if aantal >=1:
                        return (aantal)
                    if aantal <1:
                        print ("U moet minimaal 1 of meer liters bestellen!")
                        continue
        except:
            snapikniet()
        

#-----------------------------------------------------------------------------------------
def smaken(aantalbolletjes) -> list:
    herhalen = aantalbolletjes
    x = 1
    smakenbolletjes = []
    while herhalen >=1:
        smaak = input(f"Welke smaak wilt u voor bolletje nummer {x} A) Aardbei, C) Chocolade, of V) Vanille? ").lower()
        if smaak == "a" or smaak == 'c' or smaak == 'v':
            smakenbolletjes.append(smaak.upper())
            herhalen -= 1
            x +=1
        else:
            snapikniet()
    return (smakenbolletjes)

#-----------------------------------------------------------------------------------------

def topping(aantalbolletjes, prijzenTopping, verpakking):
    while True:
        topping = input("Wat voor topping wilt u: A) Geen, B) Slagroom, C) Sprinkels of D) Caramel Saus? ").lower()
        if topping == 'a':
            return (0)
        if topping == 'b':
            return (prijzenTopping['prijsslagroom'])
        if topping == "c":
            return (aantalbolletjes * prijzenTopping['prijssprinkels'])
        if topping == 'd' and verpakking == 'bakjes':
            return (prijzenTopping['prijscaramelsausBakje'])
        if topping == 'd' and verpakking == 'hoorntjes':
            return (prijzenTopping['prijscaramelsausHoorntje'])
        else:
            snapikniet()

#-----------------------------------------------------------------------------------------

def verpakking(aantalbolletjes):
    herhaling = True
    while herhaling == True:
        if aantalbolletjes >= 1 and aantalbolletjes <= 3:
            bakjeofhoorntjewil = input(f"Wilt u deze {aantalbolletjes} bolletjes in een hoorntje of bakje? ").lower()
            if bakjeofhoorntjewil == "bakje":
                return ("bakjes")
            elif bakjeofhoorntjewil == "hoorntje":
                return ("hoorntjes")
            else:
                snapikniet()
        if aantalbolletjes >= 4 and aantalbolletjes <= 8:
            return ("bakjes")

#-----------------------------------------------------------------------------------------

def beiden(aantalbolletjes, verpakkingen):
    if verpakkingen == "bakje":
        return print (f"Hier is uw bakje met {aantalbolletjes} bolletjes")
    if verpakkingen == "hoorntje":
        return print (f"Hier is uw hoorntje met {aantalbolletjes} bolletjes")
    
#-----------------------------------------------------------------------------------------

def nogmeerbestellen():
    foutantwoord = True
    while foutantwoord == True:
        nogeenkeer = input("Wilt u nog meer bestellen? ").lower()
        if nogeenkeer == "ja":
            foutantwoord = False
            return ("ja")
        elif nogeenkeer == 'nee':
            return ("nee")
        else:
            snapikniet()
            
#-----------------------------------------------------------------------------------------

def bonnetjeparticulier(aantallen, smakenbolletjes, totaalToppings):
    aantalaardbij = smakenbolletjes.count("A")
    aantalchocolade = smakenbolletjes.count("C")
    aantalvanille = smakenbolletjes.count("V")
    aantal1 = 0
    aantal2 = 0
    aantal3 = 0
    totaalprijsTopping = 0.0
    for i in range (len(totaalToppings)):
        totaalprijsTopping += (totaalToppings[i])

    print (f"---------[Papi Gelato]---------")
    if aantallen['bolletjes'] >=1:
        if aantalaardbij >=1:
            print (f" B.aardbei    {aantalaardbij} x €{PRIJS_PER_BOLLETJE} = €{format(round(aantalaardbij * PRIJS_PER_BOLLETJE,2), '.2f')}")
        if aantalchocolade >=1:
            print (f" B.chocolade  {aantalchocolade} x €{PRIJS_PER_BOLLETJE} = €{format(round(aantalchocolade * PRIJS_PER_BOLLETJE,2), '.2f')}")
        if aantalvanille >=1:
            print (f" B.vanille    {aantalvanille} x €{PRIJS_PER_BOLLETJE}= €{format(round(aantalvanille *PRIJS_PER_BOLLETJE,2), '.2f')}")
        aantal1 = aantallen['bolletjes'] * PRIJS_PER_BOLLETJE
    if aantallen['hoorntjes'] >=1:
        print (f" Hoorntjes    {aantallen['hoorntjes']} x €{PRIJS_PER_HOORNTJE} = €{format(round(aantallen['hoorntjes'] * PRIJS_PER_HOORNTJE,2), '.2f')}")
        aantal2 = aantallen['hoorntjes'] * PRIJS_PER_HOORNTJE
    if aantallen['bakjes'] >=1:
        print (f" Bakjes       {aantallen['bakjes']} x €{PRIJS_PER_BAKJE} = €{format(round(aantallen['bakjes'] * PRIJS_PER_BAKJE,2), '.2f')}")
        aantal3 = aantallen['bakjes'] * PRIJS_PER_BAKJE
    if totaalprijsTopping >0:
        print (f" Topping                = €{format(totaalprijsTopping, '.2f')}")
    print (f"                      ------- +")
    print (f" Totaal                 = €{format(round(aantal1 + aantal2 + aantal3 + totaalprijsTopping,2), '.2f')} ")

def welkombij():
    return print ("Welkom bij Papi Gelato")

#-----------------------------------------------------------------------------------------

def smakenliters(aantalliters) -> list:
    herhalen = aantalliters
    x = 1
    smakenliters = []
    while herhalen >=1:
        smaak = input(f"Welke smaak wilt u voor liters {x} A) Aardbei, C) Chocolade, of V) Vanille? ").lower()
        if smaak == "a" or smaak == 'c' or smaak == 'v':
            smakenliters.append(smaak.upper())
            herhalen -= 1
            x +=1
        else:
            snapikniet()
    return (smakenliters)

#-----------------------------------------------------------------------------------------

def bonnetjezakelijk(aantallen, smakenliters):
    aantalaardbij = smakenliters.count("A")
    aantalchocolade = smakenliters.count("C")
    aantalvanille = smakenliters.count("V")
    print (f"---------[Papi Gelato]---------")
    if aantallen['liters'] >=1:
        if aantalaardbij >=1:
            print (f" L.aardbei    {aantalaardbij} x €{format(PRIJS_PER_LITER, '.2f')} = €{format(round(aantalaardbij * PRIJS_PER_LITER,2), '.2f')}")
        if aantalchocolade >=1:
            print (f" L.chocolade  {aantalchocolade} x €{format(PRIJS_PER_LITER, '.2f')} = €{format(round(aantalchocolade * PRIJS_PER_LITER,2), '.2f')}")
        if aantalvanille >=1:
            print (f" L.vanille    {aantalvanille} x €{format(PRIJS_PER_LITER, '.2f')} = €{format(round(aantalvanille * PRIJS_PER_LITER,2), '.2f')}")
    print (f"                      ------- +")
    print (f" Totaal                = €{format(round(aantallen['liters'] * PRIJS_PER_LITER,2), '.2f')} ")
    totaalprijs = round((aantallen['liters'] * PRIJS_PER_LITER),2)
    zonderbtw = totaalprijs / 106 * 100
    btw = abs(round(zonderbtw - totaalprijs,2))
    print (f" BTW (6%)              = €{btw}")

#-----------------------------------------------------------------------------------------