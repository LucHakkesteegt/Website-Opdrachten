var listPartijen = ["PvdD", "VVD", "BBB", "D66", "SGP"]
var aantalpartijen = listPartijen.length;
var aantalstemmen = []
var gewonnenpartijen = []
var ids = -1;

for (let a = 0; a < aantalpartijen; a++) {
    aantalstemmen.push(0)
}

for (let i = 0; i < aantalpartijen; i++) {
    var clickMeButton = document.createElement('button');
    clickMeButton.setAttribute('style', 'padding: 10px; margin-right: 10px; margin-bottom: 25px;')
    const container = document.getElementById("container");
    clickMeButton.innerHTML = listPartijen[i];
    clickMeButton.style.backgroundColor = "#FC5130"
    let id = clickMeButton.id = (ids +=1)
    clickMeButton.setAttribute("onclick", "optellen(id, aantalstemmen)");
    container.appendChild(clickMeButton);
}
var submit = document.createElement('button');
submit.setAttribute('style', 'padding: 10px; margin-left: 100px; margin-top: 25px; margin-bottom: 25px;')
const container = document.getElementById("container");
submit.innerHTML = "Tellen";
submit.style.backgroundColor = "#4CBB17"
let id = submit.id = submit;
submit.setAttribute("onclick", "uitslag()");
container.appendChild(submit);


function optellen (id, aantalstemmen) {
    aantalstemmen[id] = (aantalstemmen[id] +=1);
} 

function uitslag () {
    for (let b = 0; b < aantalpartijen; b++) {
        const element = document.getElementById(b);
        element.remove();
    }
    const element2 = document.getElementById(submit);
    element2.remove();
    for (let c = 0; c < aantalpartijen; c++) {
        var pelement = document.createElement('p1');
        pelement.setAttribute('style', 'font-size: 25px;')
        const container = document.getElementById("container");
        tekstvoorinhtml = String(listPartijen[c]) + " heeft " +  String(aantalstemmen[c]) + " stemmen!" + "<br>";
        pelement.innerHTML = tekstvoorinhtml
        container.appendChild(pelement);

    }
    for (let d = 0; d < aantalpartijen; d++) {
        var max = 0
        for (var e = 0; e < aantalpartijen; e++) {
            if (aantalstemmen[e] > max) {
                max = aantalstemmen[e];
                var maxIndex = e;
            }
        }
    }
    for (let f = 0; f < aantalpartijen; f++) {
        index = f
        if (aantalstemmen[maxIndex] == aantalstemmen[f] && aantalstemmen[maxIndex] != 0) {
            gewonnenpartijen.push(index)
        }
    }


    var p2element = document.createElement('p1');
    p2element.setAttribute('style', 'font-size: 25px;')
    const container = document.getElementById("container"); 

    totaalstring = ""
    if (gewonnenpartijen.length > 1 ) {
        for (let h = 0; h < gewonnenpartijen.length; h++) {
            indexx = gewonnenpartijen[h]
            totaalstring = totaalstring + String(listPartijen[indexx]) + ", "
            
        }
    } else if ( gewonnenpartijen.length == 1 ) {
        indexx = gewonnenpartijen
        totaalstring = String(listPartijen[indexx])
    } else if ( gewonnenpartijen.length == 0) {
        totaalstring = "Niemand "
    }
    tekstvoorinhtml = "<br>" + totaalstring + " heeft gewonnen!";
    p2element.innerHTML = tekstvoorinhtml
    container.appendChild(p2element);
}

